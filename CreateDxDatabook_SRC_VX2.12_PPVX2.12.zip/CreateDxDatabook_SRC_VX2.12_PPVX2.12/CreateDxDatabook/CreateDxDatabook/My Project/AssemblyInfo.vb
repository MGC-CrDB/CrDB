﻿Imports System.Resources

Imports System
Imports System.Reflection
Imports System.Runtime.InteropServices

' Allgemeine Informationen über eine Assembly werden über die folgenden 
' Attribute gesteuert. Ändern Sie diese Attributwerte, um die Informationen zu ändern,
' die mit einer Assembly verknüpft sind.

' Die Werte der Assemblyattribute überprüfen

<Assembly: AssemblyTitle("CreateDxDatabook")> 
<Assembly: AssemblyDescription("Creates a DxDatabook MDB File from Central Library")> 
<Assembly: AssemblyCompany("Mentor Graphics")> 
<Assembly: AssemblyProduct("CreateDxDatabook")> 
<Assembly: AssemblyCopyright("Copyright © 2016")> 
<Assembly: AssemblyTrademark("")> 

<Assembly: ComVisible(False)> 

'Die folgende GUID bestimmt die ID der Typbibliothek, wenn dieses Projekt für COM verfügbar gemacht wird
<Assembly: Guid("0b491d70-bbc3-422b-8694-81f6e70f4a54")>

' Versionsinformationen für eine Assembly bestehen aus den folgenden vier Werten:
'
'      Hauptversion
'      Nebenversion 
'      Buildnummer
'      Revision
'
' Sie können alle Werte angeben oder die standardmäßigen Build- und Revisionsnummern 
' übernehmen, indem Sie "*" eingeben:
' <Assembly: AssemblyVersion("1.0.*")> 

<Assembly: AssemblyVersion("8.9.2.12")>
<Assembly: AssemblyFileVersion("8.9.2.12")>

<Assembly: NeutralResourcesLanguageAttribute("en-US")> 